package consequence;

public class ConsequenceDTO {
	private String co_result;
	private String co_attend;
	private String co_comple;
	private String co_employ;
	private String co_same;
	private String co_insurance;
	private String co_option1;
	private String co_option2;
	private String co_option3;
	private String co_option4;
	private String co_option5;
	private String co_option6;
	private String co_asse;
	private String co_porf;
	private String co_certificate;
	private int m_id;
	
	
	public String getCo_result() {
		return co_result;
	}
	public void setCo_result(String co_result) {
		this.co_result = co_result;
	}
	public String getCo_attend() {
		return co_attend;
	}
	public void setCo_attend(String co_attend) {
		this.co_attend = co_attend;
	}
	public String getCo_comple() {
		return co_comple;
	}
	public void setCo_comple(String co_comple) {
		this.co_comple = co_comple;
	}
	public String getCo_employ() {
		return co_employ;
	}
	public void setCo_employ(String co_employ) {
		this.co_employ = co_employ;
	}
	public String getCo_same() {
		return co_same;
	}
	public void setCo_same(String co_same) {
		this.co_same = co_same;
	}
	public String getCo_insurance() {
		return co_insurance;
	}
	public void setCo_insurance(String co_insurance) {
		this.co_insurance = co_insurance;
	}
	public String getCo_option1() {
		return co_option1;
	}
	public void setCo_option1(String co_option1) {
		this.co_option1 = co_option1;
	}
	public String getCo_option2() {
		return co_option2;
	}
	public void setCo_option2(String co_option2) {
		this.co_option2 = co_option2;
	}
	public String getCo_option3() {
		return co_option3;
	}
	public void setCo_option3(String co_option3) {
		this.co_option3 = co_option3;
	}
	public String getCo_option4() {
		return co_option4;
	}
	public void setCo_option4(String co_option4) {
		this.co_option4 = co_option4;
	}
	public String getCo_option5() {
		return co_option5;
	}
	public void setCo_option5(String co_option5) {
		this.co_option5 = co_option5;
	}
	public String getCo_option6() {
		return co_option6;
	}
	public void setCo_option6(String co_option6) {
		this.co_option6 = co_option6;
	}
	public String getCo_asse() {
		return co_asse;
	}
	public void setCo_asse(String co_asse) {
		this.co_asse = co_asse;
	}
	public String getCo_porf() {
		return co_porf;
	}
	public void setCo_porf(String co_porf) {
		this.co_porf = co_porf;
	}
	public String getCo_certificate() {
		return co_certificate;
	}
	public void setCo_certificate(String co_certificate) {
		this.co_certificate = co_certificate;
	}
	public int getM_id() {
		return m_id;
	}
	public void setM_id(int m_id) {
		this.m_id = m_id;
	}
	
	
	
}
